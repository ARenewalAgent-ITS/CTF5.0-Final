const express = require('express');
const { exec } = require('child_process');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const executeCommand = async (command) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(`Error: ${stdout}`);
            } else {
                resolve(stdout);
            }
        });
    });
};

app.post('/submit', async (req, res) => {
    const text = req.body.text;

    // random 8 character file name
    let random = (Math.random() + 1).toString(36).substring(7);
    let temp = path.join(__dirname, 'tmp');
    temp = path.join(temp, random + '.go');

    fs.mkdirSync(path.dirname(temp), { recursive: true });
    fs.writeFileSync(temp, text);

    const command = `./main "${temp}"`;
    console.log(command);

    try {
        const output = await executeCommand(command);
        res.json({ output });
    } catch (error) {
        res.status(500).json({ output: error });
    }
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
